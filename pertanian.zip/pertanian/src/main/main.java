/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import CRUD.database;
/**
 *
 * @author Farhan
 */
public class main {
    public static void main(String[] args) {
        database dbconnect = new database();
        
                // Tabel Produk
        //dbconnect.simpanproduk("1", "1", "1", "1", "1", "1", "1", "1", "1");
        //dbconnect.ubahproduk("1", "1", "1", "2", "2", "2", "1", "1", "1");
        dbconnect.hapusproduk("1");
        
                
                // Tabel Kategori
        //dbconnect.simpankategori("1", "nama_kat", "fotkat");
        //dbconnect.ubahkategori("1", "nama", "fotkat");
        dbconnect.hapuskategori("1");
        
                // Tabel Sesi
        //dbconnect.simpansesi("1", "2024-02-03", "idkoperasi", "idbuyer");
        //dbconnect.ubahsesi("1", "2024-02-24", "idkoperasi", "idbuyer");
        dbconnect.hapussesi("1");
        
                // Tabel buyer
        //dbconnect.simpanbuyer("1", "nabuy", "alambuy", "emailbuy", "1", "1", "2024-02-03");
        //dbconnect.ubahbuyer("1", "nabuy", "alambuy", "emailbuy", "1", "1", "2024-02-24");
        dbconnect.hapusbuyer("1");
        
    }   
}


