/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CRUD;

import java.security.Timestamp;
import java.sql.Connection; // mendapatkan koneksi
import java.sql.DriverManager; // menghubungkan database
import java.sql.PreparedStatement; // perintah sql (CRUD)

/**
 *
 * @author Farhan
 */
public class database {
    private String databasename = "penjualan_tani";
    private String username = "root";
    private String password = "";
    public static Connection connectionDB;
    
    
    public database(){
        try {
            String location = "jdbc:mysql://localhost/" + databasename;
            Class.forName("com.mysql.jdbc.Driver");
            connectionDB = DriverManager.getConnection(location, username, password);
            System.out.println("Database Terkoneksi");
           
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
//    public void simpanuji(String nik, String nama, String telp, String alamat){
//        try {
//            String sql = "insert into uji(nik, nama, telp, alamat) value(?,?,?,?) ";
//            PreparedStatement perintah = connectionDB.prepareStatement(sql);
//            perintah.setString(1, nik);
//            perintah.setString(2, nama);
//            perintah.setString(3, telp);
//            perintah.setString(4, alamat);
//            
//            perintah.executeUpdate();
//            System.out.println("Data berhasil tersimpan");
//            
//        } catch (Exception e) {
//            System.out.println(e.getMessage());
//        }
//    }
//    public void ubahuji(String nik, String nama, String telp, String alamat){
//        try {
//            String sql = "Update uji set nama = ?, telp = ?, alamat = ? where nik = ?";
//            PreparedStatement perintah = connectionDB.prepareStatement(sql);
//            perintah.setString(1, nama);
//            perintah.setString(2, telp);
//            perintah.setString(3, alamat);
//            perintah.setString(4, nik);
//            
//            perintah.executeUpdate();
//            System.out.println("Data berhasil terubah");
//            
//        } catch (Exception e) {
//            System.out.println(e.getMessage());
//        }
//    }
//    public void hapusuji(String nik){
//        try {
//            String sql = "delete from uji where nik = 1";
//            PreparedStatement perintah = connectionDB.prepareStatement(sql);
//            
//            perintah.executeUpdate();
//            System.out.println("Data berhasil dihapus");
//            
//        } catch (Exception e) {
//            System.out.println(e.getMessage());
//        }
//    }
    
    //Tabel Sesi
    public void simpansesi(String id_sesi, String waktu, String koperasi, String buyer){
        try {
            String sql = "insert into sesi(id_sesi, waktu, koperasi, buyer) value(?,?,?,?)";
            PreparedStatement perintah = connectionDB.prepareStatement(sql);
            perintah.setString(1, id_sesi);
            perintah.setString(2, waktu);
            perintah.setString(3, koperasi);
            perintah.setString(4, buyer);
            
            perintah.executeUpdate();
            System.out.println("Data berhasil tersimpan");
        } catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void ubahsesi(String id_sesi, String waktu, String koperasi, String buyer){
        try {
            String sql = "Update sesi set waktu = ?, koperasi = ?, buyer = ? where id_sesi = ?" ;
            PreparedStatement perintah = connectionDB.prepareStatement(sql);
            perintah.setString(1, waktu);
            perintah.setString(2, koperasi);
            perintah.setString(3, buyer);
            perintah.setString(4, id_sesi);
            
            perintah.executeUpdate();
            System.out.println("Data berhasil tersimpan");
        } catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void hapussesi(String id_sesi){
        try {
            String sql = "delete from sesi where id_sesi = 1";
            PreparedStatement perintah = connectionDB.prepareStatement(sql);
            
            perintah.executeUpdate();
            System.out.println("Data berhasil dihapus");
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    // Tabel Kategori
    public void simpankategori(String id_kategori, String nama_kategori, String foto_kategori){
        try {
            String sql = "insert into kategori(id_kategori,nama_kategori, foto_kategori) value(?,?,?)";
            PreparedStatement perintah = connectionDB.prepareStatement(sql);
            perintah.setString(1, id_kategori);
            perintah.setString(2, nama_kategori);
            perintah.setString(3, foto_kategori);
            
            perintah.executeUpdate();
            System.out.println("Data berhasil tersimpan");
        } catch (Exception e){
            System.out.println(e.getMessage());
        }
        
    }
        public void ubahkategori(String id_kategori, String nama_kategori, String foto_kategori){
        try {
            String sql = "Update kategori set nama_kategori = ?, foto_kategori = ? where id_kategori = ?" ;
            PreparedStatement perintah = connectionDB.prepareStatement(sql);
            perintah.setString(1, nama_kategori);
            perintah.setString(2, foto_kategori);
            perintah.setString(3, id_kategori);
            
            perintah.executeUpdate();
            System.out.println("Data berhasil tersimpan");
        } catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void hapuskategori(String id_kategori){
        try {
            String sql = "delete from kategori where id_kategori = 1";
            PreparedStatement perintah = connectionDB.prepareStatement(sql);
            
            perintah.executeUpdate();
            System.out.println("Data berhasil dihapus");
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    // Tabel Buyer
    public void simpanbuyer(String id_buy, String nama_buy, String alamat_buy, String email_buy, 
            String user_buy, String pass_buy, String waktu_buy){
        try {
            String sql = "insert into buyer( id_buy,  nama_buy,  alamat_buy,  email_buy, user_buy,  pass_buy,  waktu_buy) value(?,?,?,?,?,?,?)";
            PreparedStatement perintah = connectionDB.prepareStatement(sql);
            perintah.setString(1, id_buy);
            perintah.setString(2, nama_buy);
            perintah.setString(3, alamat_buy);
            perintah.setString(4, email_buy);
            perintah.setString(5, user_buy);
            perintah.setString(6, pass_buy);
            perintah.setString(7, waktu_buy);
            
            perintah.executeUpdate();
            System.out.println("Data berhasil tersimpan");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
        public void ubahbuyer(String id_buy, String nama_buy, String alamat_buy, String email_buy, 
            String user_buy, String pass_buy, String waktu_buy){
        try {
            String sql = "Update buyer set nama_buy = ?, alamat_buy = ?, email_buy = ?, user_buy = ?, pass_buy = ?, waktu_buy = ? where id_buy = ?" ;
            PreparedStatement perintah = connectionDB.prepareStatement(sql);
            perintah.setString(1, nama_buy);
            perintah.setString(2, alamat_buy);
            perintah.setString(3, email_buy);
            perintah.setString(4, user_buy);
            perintah.setString(5, pass_buy);
            perintah.setString(6, waktu_buy);
            perintah.setString(7, id_buy);
            
            perintah.executeUpdate();
            System.out.println("Data berhasil tersimpan");
        } catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void hapusbuyer(String id_buy){
        try {
            String sql = "delete from buyer where id_buy = 1";
            PreparedStatement perintah = connectionDB.prepareStatement(sql);
            
            perintah.executeUpdate();
            System.out.println("Data berhasil dihapus");
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    // Tabel Produk
        public void simpanproduk(String id_produk, String nama_produk, String stok_barang, String harga_awal, 
            String harga_jual, String foto_barang, String kategori, String id_sesi, String sesi_koperasi){
        try {
            String sql = "insert into produk(id_produk, nama_produk, stok_barang, harga_awal, harga_jual, foto_barang, kategori, id_sesi, sesi_koperasi) value(?,?,?,?,?,?,?,?,?)";
            PreparedStatement perintah = connectionDB.prepareStatement(sql);
            perintah.setString(1, id_produk);
            perintah.setString(2, nama_produk);
            perintah.setString(3, stok_barang);
            perintah.setString(4, harga_awal);
            perintah.setString(5, harga_jual);
            perintah.setString(6, foto_barang);
            perintah.setString(7, kategori);
            perintah.setString(8, id_sesi);
            perintah.setString(9, sesi_koperasi);
            
            perintah.executeUpdate();
            System.out.println("Data berhasil tersimpan");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
        public void ubahproduk(String id_produk, String nama_produk, String stok_barang, String harga_awal, 
            String harga_jual, String foto_barang, String kategori, String id_sesi, String sesi_koperasi){
        try {
            String sql = "Update produk set nama_produk = ?, stok_barang = ?, harga_awal = ?, harga_jual = ?, foto_barang = ?, kategori = ?, id_sesi = ?, sesi_koperasi = ? where id_produk = ?" ;
            PreparedStatement perintah = connectionDB.prepareStatement(sql);
            perintah.setString(1, nama_produk);
            perintah.setString(2, stok_barang);
            perintah.setString(3, harga_awal);
            perintah.setString(4, harga_jual);
            perintah.setString(5, foto_barang);
            perintah.setString(6, kategori);
            perintah.setString(7, id_sesi);
            perintah.setString(8, sesi_koperasi);
            perintah.setString(9, id_produk);
            
            perintah.executeUpdate();
            System.out.println("Data berhasil tersimpan");
        } catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void hapusproduk(String id_produk){
        try {
            String sql = "delete from produk where id_produk = 1";
            PreparedStatement perintah = connectionDB.prepareStatement(sql);
            
            perintah.executeUpdate();
            System.out.println("Data berhasil dihapus");
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
